import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class PlayerService {
  private readonly _name = signal('');

  readonly name = this._name.asReadonly();

  setName(name: string): void {
    this._name.set(name.trim());
  }

  hasName(): boolean {
    return this._name().trim().length > 0;
  }
}
