import { CUSTOM_ELEMENTS_SCHEMA, Component, signal } from '@angular/core';
import { Router } from '@angular/router';
import { PlayerService } from '../../core/services/player.service';

@Component({
  selector: 'app-home',
  standalone: true,
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
})
export class HomeComponent {
  protected readonly name = signal('');

  constructor(
    private readonly router: Router,
    private readonly player: PlayerService,
  ) {}

  protected onInput(ev: Event): void {
    const d = (ev as CustomEvent<string>).detail;
    this.name.set(typeof d === 'string' ? d : '');
  }

  protected acceder(): void {
    if (!this.hasName()) {
      return;
    }
    this.player.setName(this.name());
    void this.router.navigate(['/game']);
  }

  protected hasName(): boolean {
    return this.name().trim().length > 0;
  }

  protected errors(): Record<string, boolean> | null {
    return this.hasName() ? null : { required: true };
  }
}
