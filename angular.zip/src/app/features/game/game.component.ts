import { Component, DestroyRef, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { interval } from 'rxjs';
import { TrafficLightComponent } from '../../shared/traffic-light/traffic-light.component';

@Component({
  selector: 'app-game',
  standalone: true,
  imports: [TrafficLightComponent],
  templateUrl: './game.component.html',
  styleUrl: './game.component.scss',
})
export class GameComponent {
  private readonly destroyRef = inject(DestroyRef);

  /** Solo demo: alterna rojo/verde cada 1s (sin lógica de partida). */
  protected readonly semaforo = signal<string>('red');

  constructor() {
    interval(1000)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => {
        this.semaforo.update((c) => (c === 'red' ? 'green' : 'red'));
      });
  }
}
